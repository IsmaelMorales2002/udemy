import { init } from "./js/chistes-page";

init();