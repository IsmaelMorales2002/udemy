# Webpack Starter

Este es el proyecto inicial para crear aplicaciones utilizando webpack.

### Notas:
Recuerden reconstruir los módulos de Node
```
npm install
```

Y para construir el build, recueren:
```
npm run build
```