# Webpack Starter

Este es el proyecto inicial para crear
aplicaciones utilizando webpack.

###
Recuerden reconstruir los modulos de node

´npm install´