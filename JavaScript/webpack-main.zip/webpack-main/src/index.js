import {saludar} from './js/componentes';
import './styles.css';


const nombre = 'Ismael';
saludar(nombre);